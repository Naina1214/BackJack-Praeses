# frozen_string_literal: true

require_relative 'player'
require_relative 'deck'

class Game
  def initialize
    player_name = welcome_note
    @player1 = Player.new(name: player_name)
    @player2 = Player.new(name: 'Dealer')
    @deck = Deck.new
    initialize_turns
    start_game
  end

  attr_accessor :player1, :player2, :deck

  def initialize_turns
    deck.assign_initial_cards
    deck.show_current_suit(1, player1.name)
    while deck.player2_cards.map(&:face_value).sum <= 16
      puts 'Dealer current total is less than or equal to 16 and forced to hit again'
      sleep(1)
      deck.assign_card('player_2')
      deck.show_current_suit(2, player1.name)
      deck.check_status('player2')
    end
  end

  def start_game
    loop do
      puts 'your turn: press 1 to Hit, press 2 to stand'
      option = gets.chomp
      puts 'Invalid option, press either 1 to Hit, press 2 to stand' until %w[1 2].include?(option)
      if option == '1'
        deck.assign_card('player1')
        deck.show_current_suit(2, player1.name)
        deck.check_status('player1')
      else
        player_hand_total = deck.get_hand_total('player1')
        dealer_hand_total = deck.get_hand_total('player2')
        if player_hand_total > dealer_hand_total
          puts 'Hurray! your hand-total is close to 21 when compared to dealer'
        elsif player_hand_total == dealer_hand_total
          puts 'Its a tie between you and dealer'
        else
          puts "sorry #{player1.name}, dealer's hand-total is close to 21 than yours"
        end
        exit
      end
    end
  end

  def welcome_note
    puts 'Welcome to Gamezone, i am the dealer here'
    puts "Its a great time to start with BlackJack\n\n"
    print "What's your name:"
    player_name = gets.chomp
    puts "Hello #{player_name}, lets get started\n\n"
    player_name
  end
end
