# frozen_string_literal: true

class Card
  def initialize(id:, category:, value:)
    @id = id
    @category = category
    @value = value
    @face_value = get_face_value
  end

  attr_accessor :id, :category, :value, :face_value

  def get_face_value
    case value
    when 'A' then 11 # it turns to 1 when the hand-total exceeds 21
    when 'K', 'Q', 'J' then 10
    else
      value
    end
  end
end
