# frozen_string_literal: true

class Player
  def initialize(name:)
    @name = name
  end

  attr_accessor :name
end
