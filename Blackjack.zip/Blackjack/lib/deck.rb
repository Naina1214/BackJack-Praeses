# frozen_string_literal: true

require_relative 'card'

class Deck
  def initialize
    @cards = []
    %w[Hearts Diamonds Clubs Spades].each do |category|
      (%w[A K Q J] + (2...10).to_a).each do |value|
        @cards << Card.new(id: "#{category}_#{value}", category: category, value: value)
      end
    end
    @player1_cards = []
    @player2_cards = []
  end

  attr_accessor :cards, :player1_cards, :player2_cards

  def assign_card(player)
    random_index = rand(cards.length)
    if player == 'player1'
      player1_cards.push(cards.delete_at(random_index))
      check_status('player1')
    else
      player2_cards.push(cards.delete_at(random_index))
    end
  end

  def get_hand_total(player)
    player == 'player1' ? player1_cards.map(&:face_value).sum : player2_cards.map(&:face_value).sum
  end

  def check_status(player)
    if player == 'player1'
      sum = player1_cards.map(&:face_value).sum
      if sum == 21
        puts "Hurray! you won the board with hand-total of #{sum}"
        exit
      elsif sum > 21
        depricable_card = player1_cards.select { |card| card.value == 'A' && card.face_value == 11 }
        unless depricable_card.empty?
          depricable_card[0].face_value = 1
          return
        end
        puts "Dealer won the board as your hand-total #{sum} is more than 21"
        exit
      end
    else
      sum = player2_cards.map(&:face_value).sum
      if sum == 21
        puts "Dealer won the board with hand-total of #{sum}"
        exit
      elsif sum > 21
        depricable_card = player2_cards.select { |card| card.value == 'A' && card.face_value == 11 }
        unless depricable_card.empty?
          depricable_card[0].face_value = 1
          return
        end
        puts "Hurry! you won the board as dealer got busted with hand-total of #{sum}"
        exit
      end
    end
  end

  def assign_initial_cards
    2.times do
      assign_card('player1')
      assign_card('player2')
    end
  end

  def show_current_suit(turn, player_name)
    player2_suit(turn)
    puts "\n\n"
    player1_suit(player_name)
    puts "\n\n"
  end

  def player2_suit(turn)
    puts '====Dealer======'
    puts ' Name: Dealer'
    player2_cards.each_with_index do |card, index|
      card_id = (turn == 1) && index.zero? ? '**********' : card.id
      face_value = (turn == 1) && index.zero? ? '**********' : card.face_value
      puts "card_#{index + 1} => #{card_id} => #{face_value}"
    end
    puts "total face_vale : #{player2_cards.map(&:face_value).sum}" unless turn == 1
  end

  def player1_suit(player_name)
    puts '====Player1======'
    puts " Name: #{player_name}"
    player1_cards.each_with_index do |card, index|
      card_id = card.id
      face_value = card.face_value
      puts "card_#{index + 1} => #{card_id} => #{face_value}"
    end
    puts "total face_vale : #{player1_cards.map(&:face_value).sum}"
  end
end
