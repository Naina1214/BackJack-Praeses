## Overview

  

This project is Black Jack game that can be played in the terminal of the user's computer. It was devloped fully in ruby as a console App.

  

## Prerequisite

Ruby V 2.7 +

  

## How to run the App?

  

you can use the below

```
cd lib
ruby main.rb
```

  

## How to play?

  

On running the main.rb using ruby, you will be asked to provide your name and on the other side system will be your dealer.

  
  

1) initially both parties would be assigned with two random cards and dealers primary card would be masked for the first turn.

  

2) For the second turn, if dealers hand-total is less than or equal to 16 he is forced to make a hit and on reaching the total more than 16 he would remain to stand/stay.

  

3) Further player would be prompted to either hit/stay and he can choose either through the numeric optiona provided.

  

4) As either parties proceed to make hits right from the initial card assignment there will a check to confirm the reach or exceeding hand-total of 21 and would be declared as winner/looser as per the total.

  

5) the face-value of ACE card would be initially treated as 11 but it would get updated to 1 if the hand-total exceeds 21.

  

6) As the player choose to stay/stand by with his existing picks the hand-total of either parties will be compared and the one close to 21 would be declared a winner.